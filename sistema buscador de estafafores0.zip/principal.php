<?php 
	session_start(); // crea o reanuda session

	if(!isset($_SESSION['login'])) {

		header("location:index.php");
	}

 ?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>BUSCADOR DE ESTAFADORES</title>

<style> 
	table{
		width: 400px;
		margin: auto;
		background: #ffc;
		border: 2px solid #f00;
		padding: 5px;
	}

	td{
		text-align: center;
	}
</style>
</head>
<body BGCOLOR="#99aaff">

		<form action="buscar.php" method="get">

			<table><tr><td><h2>Introducir datos sin separadores: </h2></td>   <td><input type="text" name="dato"> </td> </tr>

			<tr><td> </td>  <td><input type="submit" name="buscar" value=" buscar >>"> </td></tr>

			</table>

		</form>


	</body>
</html>