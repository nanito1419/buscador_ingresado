<!DOCTYPE html>
<html>
<head>
  <script src="https://www.google.com/recaptcha/api.js" async defer></script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>BU-fon</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="estiloscss/estilo.css">
  <link rel="shortcut icon" type="imagen/bufon2-png" href="img/48855.png">

</head>
 <body>

  <nav class="navbar navbar-fixed-top navbar-dark bg-dark ">
      <a class="navbar-brand" href="#">
       <img src="img/socor.png" width="260" height="55" class="d-inline-block align-top" alt="">
      </a>
       <ul class="nav navbar-nav navbar-right">
         <img src="img/bufon.png" width="260" height="55" class="d-inline-block align-top" alt="">
       </ul>
  </nav>


  <br><br>
<div class="container">
      <div class="card-deck">
        <div class="card text-white card-dark bg-dark">
          <div class="card-body">
           <h2 align="center" class="card-title" id="color1">QUE ES BU-FON</h2> <h3 align="center" class="card-title" id="color1">Es un buscador con una base de datos de personas cuyos datos (numero de telefonos, DNI y correo) se han utilizado para llevar acabo una estafa, los datos que se encuentran en ella fueron recopilados entres sus miembro. nosotros no nos hacemos responsable de la informacion suministrada, cualquier inconveniente o duda puede comunicarse con soporte!!</h3><br>
           <br>
          </div>
        </div>

  <div class="container">
      <div class="card-deck">
        <div class="card text-white card-dark bg-dark">
          <div class="card-body">
           <h2 align="center" class="card-title" id="color1">QUIENES SOMOS!!!</h2> <h3 align="center" class="card-title" id="color1">Somos un grupo de programadores buscando crear herramientas utiles para el bien comun. <br>el acceso a dicho sistema tendra un coste de 2$ trimetral (por 3 meses), se puede financiar el acceso comunicate con soporte!!!</h3><br>
           <br>
          </div>
        </div>



  <br><br>
  <div class="container">
    <div class="row justify-content-center pt-5 nt-5 ">
      <div class="col-md-4 formulario">
        <form action="comprueba_login.php" method="POST">
          <div class="form-group text-center">
             <h1>Iniciar Sesion</h1>
          </div>
          <div class="form-group mx-sm-4">
            <input type="text" class="form-control" placeholder="Ingrese su Usuario" name="name" >
          </div>
          <div class="form-group mx-sm-4">
            <input type="password" class="form-control" placeholder="Ingrese su Contraseña" name="password">
          </div>
          <div class="form-group mx-sm-4">
          <div class="g-recaptcha" data-sitekey="6LfBY68UAAAAAG6P6YMpYRH51b3TyYLwUKz9HMDY"></div> </div>
          <div class="form-group mx-sm-4">
            <input type="submit" class="btn btn-block btn-danger" value="INGRESAR">
          </div>
        </form>
      </div>
    </div>
  </div>
  <br><br><br><center>
    <div class="row justify-content-center pt-5 nt-5">
       <h2 id="seguir">Contactanos por telegram</h2>
    </div>
   
  <br><br><br>

   
  <div class="card">
    <a href="https://t.me/socorca"><img src="img/telegram.png" class="card-img-top" alt="..."></a>
    <div class="card-body bg-dark">
      <h5 class="card-title text-white">¡ CONTACTANOS !</h5>
    </div>
    <div class="bg-dark">
      <a href="https://t.me/socorca" class="btn btn-danger btn-lg btn-block">Ir a la pagina</a>
    </div>
  </div>
  </center>

</div>
</div>


	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
<body>
</html>