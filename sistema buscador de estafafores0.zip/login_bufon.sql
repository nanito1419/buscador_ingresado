-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 18-06-2022 a las 22:37:26
-- Versión del servidor: 10.4.21-MariaDB
-- Versión de PHP: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `buscador`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estafadores`
--

CREATE TABLE `estafadores` (
  `id_estafa` int(12) NOT NULL,
  `cedula` varchar(12) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(11) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `n_cuenta` varchar(20) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL,
  `banco` varchar(353) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `estafadores`
--

INSERT INTO `estafadores` (`id_estafa`, `cedula`, `telefono`, `n_cuenta`, `banco`) VALUES
(1, '20569118', '04126484888', '010201020102', 'venenzuela');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `login_bufon`
--

CREATE TABLE `login_bufon` (
  `ID_cliente` int(4) NOT NULL,
  `correo` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `celular` varchar(30) DEFAULT NULL,
  `cedula_client` varchar(20) NOT NULL,
  `confirmado` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `login_bufon`
--

INSERT INTO `login_bufon` (`ID_cliente`, `correo`, `password`, `celular`, `cedula_client`, `confirmado`) VALUES
(1, '[nanito@gmail.com]', '[1419]', '[0412]', '', 'SI'),
(2, '[ana@gmail.com]', '[0510]', '[0414]', '', 'NO'),
(3, 'g@gmail.com', '$2y$10$k0pytpaB/sXD5I4bGv', '77', '14', 'SI'),
(4, 'a', '$2y$10$uYiRsrwWuCAxD2gvLr', '10', '10', ''),
(5, 'b', '$2y$10$mPZKDR1xbd.LFPJcun3kROOWnf.y', 'b1', 'b1', ''),
(6, 'c', '$2y$10$cy01vl7W0SBClqcxrb99L.og/D2Ids3ezmBetbJwPtDWaqXIPIv.m', 'c', 'c', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `estafadores`
--
ALTER TABLE `estafadores`
  ADD PRIMARY KEY (`id_estafa`);

--
-- Indices de la tabla `login_bufon`
--
ALTER TABLE `login_bufon`
  ADD PRIMARY KEY (`ID_cliente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `estafadores`
--
ALTER TABLE `estafadores`
  MODIFY `id_estafa` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `login_bufon`
--
ALTER TABLE `login_bufon`
  MODIFY `ID_cliente` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
