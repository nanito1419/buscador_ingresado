
 <?php
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }

  ?>
<?php
	
	require("captchar_validator.php");

	$login1=htmlentities(addslashes($_POST["name"]));
	
	$password1=htmlentities(addslashes($_POST["password"]));

	$captcha=$_POST['g-recaptcha-response'];
	
	include("conexion.php");	
	validator($login1, $password1, $captcha);
	
	/*function ver_verificado($ID, $login)
	{
			$conexion=conexion();
			$sql="SELECT correo, confirmado FROM login_bufon WHERE correo = :login";
			$resultado=$conexion->prepare($sql);	
			$resultado->execute(array(':login'=>$login));
			$num_encontrado=$resultado->rowcount();
		if($num_encontrado==1) //se encontro el correo en la tabla
		{
			while($consulta=$resultado->fetch(PDO::FETCH_ASSOC)) //VERIFICADOR DE QUE REGISTRO UN PAGO, DE LO CONTRARIO
			{
					if($consulta['confirnado']=='SI')// se loguea por ya esta verificado el deposito
				{
					SESSION_START();
					$_SESSION["login"]=$consulta['correo'];
					header("location:principal?usuario=$login"); //colocar direccion de pagina principal de login
					
					//header("location:adentro/pagina_arbol.php?usuario=" . $nombre . "&id=" . $id);	// pasar 2 o mas variable por un header			
					
				}
				ELSEIF($consulta['confirmado']=='NO') // aqui ya registro el pago, pero no se ha verificado.
				{
					echo"estas registrado pero no has cancelado el servicio";
					//NO ENTRO, XQ NO ESTA CONFIRMADO
				
					//header("location:portada.php?espera='1'");  // cree una condicional en el index para q cuano le diera un valor a una variable lo llevara a otra pagina con un mensaje
				
				}
			}
		}ELSEIF($num_encontrado==0)// aqui no se a registrado el deposito
		{
			
			echo "no aparece registrado en la base de datos";
			//header("location:detalle_deposito2.php?id=$ID"); 
		}		
	} */		
		
	
	

?>