<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Bufon</title>
</head>
<body BGCOLOR="#99aaff">

		<?php
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }

    ?>

<br><br><br><br><br> <center><h2>

<?php

	include("conexion.php");

	function update_ticker ($user_login, $ticker)  // ( 5 ) actualizar ticker
	{

		try 
		{
			$ticker = $ticker-1;
			$conexion=conexion();
			$sql="UPDATE login_bufon SET ticker=:tick  WHERE correo=:user";
			$resultado=$conexion->prepare($sql);
			$resultado->execute(array(":user"=>$user_login, ":tick"=>$ticker )  );

					
		}catch(Exception $e)
			{
				die ('error bruto' . $e->Getmessage());
			} 
		//finally{$base=null;
	}
	

	$user_login = $_SESSION['login'];

	function capture_IDcliente($correo, $cedula, $telf, $user_login) //(1)
	{
		try{
			$conexion = conexion();
			$sql = "SELECT * FROM login_bufon WHERE correo= :corr ";
			$resultado=$conexion->prepare($sql);
			$resultado->execute(array(':corr'=>$user_login));
			while($registro=$resultado->fetch(PDO::FETCH_ASSOC))
			{
				$ticker=$registro['ticker'];
				comparar_existeEstafador($correo, $cedula, $telf, $user_login, $ticker);
				
			}

			}catch(Exception $e)
			{
				die ('error bruto' . $e->Getmessage());
			} 
		//finally{$conexion=null;}
	}	 

	function insertar_estafador ($correo, $cedula, $telf, $user_login, $ticker)  //( 3 ) insertar datos.
	{
		$conexion=conexion();		
		$sql="INSERT INTO estafadores (cedula, telefono, correo_cuenta, registrado_por ) VALUES(:cedu, :telefhono, :correo_c, :id_refe)";		
		$resultado=$conexion->prepare($sql);
		$resultado->execute(array(':cedu'=>$cedula, ':telefhono'=>$telf, ':correo_c'=>$correo, ':id_refe'=>$user_login));
		update_ticker ($user_login, $ticker);
		$resultado->closeCursor();
		// header o mensaje de ya registardo
	}

	function compara_conUser($correo, $cedula, $telf, $user_login, $ticker)  // ( 3 ) revisar si el que se esta registrando esta registrado como user
	{
		try{

			$conexion=conexion();
			$sql="SELECT * FROM login_bufon WHERE correo = :correo || celular = :telef || cedula_client = :ced";
			$resultado=$conexion->prepare($sql);
			$resultado->execute(array(":correo"=>$correo, ":telef"=>$telf, ":ced"=>$cedula));
			$num_encontrado2=$resultado->rowcount();
		
				if($num_encontrado2==0)
				{
					//no esta registrado en la lista de client 
					insertar_estafador($correo, $cedula, $telf, $user_login, $ticker);
				
				}
				else 
				{

					echo "estas intentando registrar un (usuario) como estafador.";  ?> <br> <?php echo " CONTACTA A SOPORTE!!! ";
				// estan intentando registrar un cliente como estafador

				/*$celco="DATOS YA REGISTRADOS, INTENTE LOGUEARSE O INTRODUSCA NUEVOS DATOS.";// SI EL CORREO O EL CELU YA ESTAN REGISTRADOS
				header("location:index?cortel=$celco");*/
				
			 	}
			}catch(Exception $e)
			{
				die ('error bruto' . $e->Getmessage());
			} //finally{$conexion=null;
	}


	function comparar_existeEstafador($correo, $cedula, $telf, $user_login, $ticker) // (2) comparar si ya existe esos datos en la base de dato de estafadores
	{ 
		if(empty($correo) and empty($cedula) and empty($telf)) //(ver si quiere enviar datos vacios), tiene que estar todos vacios para devolverse
		{
			
			//header("location:formulario_registro.php?error=$orror");
			echo "No rellenaste ninguna casilla!!!";
		}
		else //ver si esta repetido
		{
			$conexion=conexion();
			$sql="SELECT correo_cuenta, telefono, cedula FROM estafadores WHERE correo_cuenta = :correo OR telefono = :telef OR cedula = :cel";
			$resultado=$conexion->prepare($sql);
			$resultado->execute(array(":correo"=>$correo, ":telef"=>$telf, ":cel"=>$cedula));
			$num_encontrado=$resultado->rowcount();

				if($num_encontrado>=1)
				{
					//PROPONER UNA FUNCION PARA VERIFICAR SI LA PERSONA QUE SE QUIERE INSCRIBIR ESTA EN LA BASE DE DATO COMO ESTAFADOR		
					/*$celco="DATOS YA REGISTRADOS, INTENTE LOGUEARSE O INTRODUSCA NUEVOS DATOS.";// SI EL CORREO O EL CELU YA ESTAN REGISTRADOS
					header("location:index?cortel=$celco");*/
					echo "algunos de los datos que estas registrando ya se encuentra en la base de dato, "; ?> <br> <?php echo  " te recomendamos que registre un dato a las vez"; 
				}
				else
				{
					compara_conUser($correo, $cedula, $telf, $user_login, $ticker);
									
				}			

		}
	}

	$correo = htmlentities(addslashes($_GET['correo'])); 
	$cedula= htmlentities(addslashes($_GET['ced']));
	$telf= htmlentities(addslashes($_GET['telf']));
	
	capture_IDcliente($correo, $cedula, $telf, $user_login);

?>
</h2>
<br><br><br><br><br><br><a href="dashboard.php"> <INPUT TYPE="button" id="regre" name="regre" VALUE="volver"></a> </center>
</body>
</html>


