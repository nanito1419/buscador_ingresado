<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Anti-Estafadores</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="estiloscss/resultado.css">
  <link rel="shortcut icon" type="imagen/bufon2-png" href="img/48855.png">
</head>
<body>
	
  <nav class="navbar navbar-fixed-top navbar-dark bg-dark ">
    <a class="navbar-brand" href="#">
      <img src="img/hola.png" width="350" height="55" class="d-inline-block align-top" alt="">
      
    </a>
      <ul class="nav navbar-nav navbar-right">
         <button class="btn btn-danger">Cerrar sesion</button>
     </ul>
   </nav>
   
<br><br>
<div class="container">
      <div class="card-deck">
        <div class="card text-white card-dark bg-dark">
          <div class="card-body">
           <h5 class="card-title" id="color1">Nombre y Apellido</h5>
           <p class="card-text">XXXXXX XXXXXXXX</p>
          </div>
        </div>
  
      <div class="card text-white card-danger bg-danger">
        <div class="card-body">        
         <h5 class="card-title" id="color1">Cedula o Pasaporte</h5>
         <p class="card-text">XXXXXX XXXXXXXX</p>
        </div>
      </div>
  
      <div class="card text-white card-danger bg-danger">
        <div class="card-body">
         <h5 class="card-title" id="color1">Numeros telefonicos</h5>
         <p class="card-text">XXXXXX XXXXXXXX</p>
        </div>
      </div>

      <div class="card text-white card-dark bg-dark">
        <div class="card-body">
         <h5 class="card-title" id="color1">Correos Electronicos</h5>
         <p class="card-text">XXXXXX XXXXXXXX</p>
        </div>
      </div>


 </div>
</div>
        

<br><br>
<div class="container">
  <div class="card-deck">
  

  <div class="card text-black card-light bg-light">
    <img src="img/banesco.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" id="color1">Banco Banesco</h5>
      <p class="card-text" id="color1">XXXX-XXXX-XXXX-XXXX</p>
    </div>
  </div>
  

   <div class="card text-white card-success bg-success">
    <img src="img/bod.png" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" id="color1">B.O.D</h5>
      <p class="card-text" id="color1">XXXX-XXXX-XXXX-XXXX</p>
    </div>
  </div>
 

 <div class="card text-white card-info bg-info">
    <img src="img/mercantil.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" id="color1">Banco Mercantil</h5>
      <p class="card-text" id="color1">XXXX-XXXX-XXXX-XXXX</p>
    </div>
  </div>

  <div class="card text-black card-light bg-light">
    <img src="img/provincial.png" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" id="color1">Bnaco Provincial</h5>
      <p class="card-text" id="color1">XXXX-XXXX-XXXX-XXXX</p>
    </div>
  </div>
</div>
</div>



<br><br>

<div class="container">
	<div class="card-deck">
  
   <div class="card text-black card-light bg-light">
    <img src="img/tesoro2.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" id="color1">Banco del Tesoro</h5>
      <p class="card-text" id="color1">XXXX-XXXX-XXXX-XXXX</p>
    </div>
  </div>
 

 <div class="card text-black card-light bg-light">
    <img src="img/venezuela2.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" id="color1">Banco de Venezuela</h5>
      <p class="card-text" id="color1">XXXX-XXXX-XXXX-XXXX</p>
    </div>
  </div>

  <div class="card text-black card-light bg-light">
    <img src="img/bicentenario.jpg" class="card-img-top" alt="...">
    <div class="card-body">
      <h5 class="card-title" id="color1">Banco Bicentenario</h5>
     <p class="card-text" id="color1">XXXX-XXXX-XXXX-XXXX</p>
    </div>
  </div>
</div>
</div>   

<br><br> 
	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>