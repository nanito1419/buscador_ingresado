<?php
//$conexion=new PDO("mysql:host=sql305.epizy.com; dbname=epiz_31979637_estafadores" , "epiz_31979637", "9PyBssMMxGaIV");

	function conexion (){
		
		try{
			$conexion=new PDO("mysql:host=localhost; dbname=buscador", "root", "");
			$conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			$conexion->exec("SET CHARACTER SET UTF8");			
			}catch(exception $e)
			{
			die("error gafo" . getMessage());			
			echo "linea del error gafo " . $e->getLine();			
			}
		return $conexion;		
	}

?> 