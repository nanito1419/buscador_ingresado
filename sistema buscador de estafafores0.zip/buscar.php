<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title></title>
</head>
		<body>

			<?php 

			include("conexion.php");

				$busqueda = $_GET["dato"];
				$base=conexion();

				if(empty($busqueda)){

					header("location:dashboard.php");
				}else{


				try{
					
					$sql="SELECT * From estafadores WHERE correo_cuenta = :dato_b || cedula = :dato_b || telefono = :dato_b";

					$resultado=$base->prepare($sql);

					$resultado->execute(array(':dato_b'=>$busqueda));

					$encontrado=$resultado->rowcount(); // esta cuenta si hubo resultado encontrado o no

					if ($encontrado!=0) 
					{

						while ($registro=$resultado->fetch(PDO::FETCH_ASSOC)) 
						{

							header("location:encontrado.php");
						//echo "ID del estafador" . $registro['id_estafa'] . "cedula" . $registro['cedula'] . "telefono" . $registro['telefono'] . "numero de cuenta" . $registro['n_cuenta'] . "BANCO" . $registro['banco'] . "<br>" ;
						
						}

						$resultado->closecursor();
						
					}
					else
					{
						header("location:noencontrado.php");
					}

					

					}catch(Exception $e){

						die ('error bruto' . $e->Getmessage());
					} finally{$base=null;}
				}//cierre del else

			?>

		</body>
</html>