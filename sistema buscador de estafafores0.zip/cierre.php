 <?php
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }

  ?>

<?php

	session_start();

	session_destroy();

	header("location:index.php");


?>