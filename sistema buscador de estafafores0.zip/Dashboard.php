<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>BU-fon</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="estiloscss/22.css">
	<link rel="shortcut icon" type="imagen/bufon2-png" href="img/48855.png">
</head>
<body>

  <?php
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }

  ?>
      <nav class="navbar navbar-fixed-top navbar-dark bg-dark ">
    <a class="navbar-brand" href="#">
      <img src="img/hola.png" width="350" height="55" class="d-inline-block align-top" alt="">
      
    </a>
      <ul class="nav navbar-nav navbar-right">
         <a href="cierre.php"><button class="btn btn-danger">Cerrar sesion</button></a>
     </ul>
   </nav>

<br>
<br>
<div>
	<div class="container">
	  <div class="row">
		<div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="hola">
				<br><br>
				<div class="form-group">
                  <label class="col-form-label col-form-label-lg" for="inputLarge"><h3 id="text1">Buscar Estafador:</h3></label>
                  <form action="buscar.php" method="GET">
                  <input class="form-control form-control-lg" type="text" placeholder="Introduzca el datos a buscar!!" id="inputLarge" name="dato">
                  <button type="submit" class="btn btn-danger btn-lg btn-block">Buscar</button>
                </form></div>
		</div>
		
		<div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" id="feo">
			<h2 id="title1">Instrucciones</h2>
			<p id="text1">
				Solo debes colocar un unico dato en la ranura para poder compararlo con la base de dato podria ser su DNI, numero de pasapote, cedula, numero de talefono o correo. introduce los numeros sin separaciones de puntos o guiones.
			
         </div>
   </div>
</div>
<br>
<div>
  <div class="container">
    <div class="row">
    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8" id="hola">
        <br><br>
        <div class="form-group">
                  <label class="col-form-label col-form-label-lg" for="inputLarge"><h3 id="text1">Registro de Estafador:</h3></label>
                  <form action="insertar_estafador.php" method="GET">
                  <label class="col-form-label col-form-label-lg" for="inputLarge"><p id="text1">introduzca el DNI, cedula, numero de pasaporte del presunto estafador.</p></label>
                  <input class="form-control form-control-lg" type="text" placeholder="Introduzca DNI, cedula, pasaporte.  " id="inputLarge" name="ced">
                  <br> <br>
                  <label class="col-form-label col-form-label-lg" for="inputLarge"><p id="text1">Introduzca el numero celular de la persona que intento estafarlo. </p></label>
                  <input class="form-control form-control-lg" type="text" placeholder="Introduzca telefono o celular" id="inputLarge" name="telf">
                  <br> <br>
                  <label class="col-form-label col-form-label-lg" for="inputLarge"><p id="text1">Introduzca correo o numero de cuenta bancaria.</p></label>
                  <input class="form-control form-control-lg" type="text" placeholder="Introduzca correo, Nº cuenta" id="inputLarge" name="correo">
                  <br>
                  <button type="submit" class="btn btn-danger btn-lg btn-block">Registrar</button>
                </form></div>
    </div>
    
    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4" id="feo">
      <h2 id="title1">Instrucciones</h2>
      <li id="text1">
        Coloca los datos del estafador en la casilla correspondiente sin guiones, puntos o espacio. 
        </li><br>
        <li id="text1">
        Lo recomendable es llenar todas las casillas, pero aun asi puedes registrar 1 solo documento. 
        </li><br>
        <li id="text1">Solo podras registrar un numero maxximo de 10 estafadores, si tienes mas informacion que registrar cominunicate por telegram)</li>
      
         </div>
   </div>
</div>

    <div class="row justify-content-center pt-5 nt-5">
       <h2 id="seguir">Siguenocards en nuestras Redes Sociales</h2>
    </div>
   
    <br>
   
   <div class="container">
  <div class="card-deck">
  <div class="card">
    <img src="img/face.jpg" class="card-img-top" alt="...">
    <div class="card-body bg-dark">
      <h5 class="card-title text-white">¡Siguenos en Facebook!</h5>
    </div>
    <div class="bg-dark">
      <a href="#" class="btn btn-danger btn-lg btn-block">Ir a la pagina</a>
    </div>
  </div>
  
  <div class="card">
    <img src="img/instagram.png" class="card-img-top" alt="...">
    <div class="card-body bg-dark">
      <h5 class="card-title text-white bg-dark">¡Siguenos en Instagram!</h5>
    </div>
    <div class="bg-dark">
      <a href="#" class="btn btn-danger btn-lg btn-block">Ir a la pagina</a>
    </div>
  </div>
  
  <div class="card">
    <img src="img/tw.png" class="card-img-top" alt="...">
    <div class="card-body bg-dark">
      <h5 class="card-title text-white">¡Siguenos en Twitter!</h5>
    </div>
    <div class="bg-dark">
      <a href="#" class="btn btn-danger btn-lg btn-block">Ir a la pagina</a>
    </div>
  </div>

</div>
</div>

	  <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>