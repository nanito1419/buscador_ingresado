<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<title>Anti-Estafadores</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="estiloscss/resultado.css">
  <link rel="shortcut icon" type="imagen/bufon2-png" href="img/48855.png">
</head>
<body>

   <?php
    session_start();
    if (!isset($_SESSION['login'])) {
      header("location:index.php");
    }

    ?>
	
  <nav class="navbar navbar-fixed-top navbar-dark bg-dark ">
    <a class="navbar-brand" href="#">
      <img src="img/hola.png" width="350" height="55" class="d-inline-block align-top" alt="">
      
    </a>
      <ul class="nav navbar-nav navbar-right">
         <a href="cierre.php"><button class="btn btn-danger">Cerrar sesion</button></a>
     </ul>
   </nav>
   
<br><br>
   <div class="container">
      <div class="card-deck">
        <div class="card text-white card-dark bg-dark">
          <div class="card-body">
           <h2 align="center" class="card-title" id="color1">ALERTA!!!</h2>  <br><center><img src="img/alerta.png" style="width:110px;height:110px;"></center><br><h3 align="center" class="card-title" id="color1">LA INFORMACION CONSULTADA APARECE REGISTRADA EN NUESTRA BASE DE DATOS</h3>
           <br> <br> <p align="center" class="card-text">le recomendamos proceda con precaucion</p>
          </div>
           <br> <center><a href="Dashboard.php"><button class="btn btn-danger">volver al buscador</button></a></center>
        </div>





	<script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>
</html>