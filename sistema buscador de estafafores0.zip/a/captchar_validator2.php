<?php 

	function validator2($name, $pass, $captcha) 
	{

		if(!empty($name) || !empty($name) || !empty($captcha))
		{
			
			$secret = "6LfBY68UAAAAAG-BwSehCMRQ31vuVsj2HrFONY_s";

			if (!$captcha) 
			{
				header("location:index.php");
				//echo "por favor validar captcha"; // no resuelven el captcha
			}

			$response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");//falta el "remoteip=www.bufon.com"

			var_dump("$response");

			$arr = json_decode($response, true);

			if($arr["success"])
			{
				comprueba_login($name, $pass);
			}
			else
			{
				header("location:index.php");
				//echo "hizo mal el captchar";//coloco el chaptchar malo

			}

		}
	}


	function comprueba_login($login1, $password1)
	{
		
		$contador=0;
		$conexion=conexion();
		$sql="SELECT * FROM login_bufon WHERE correo = :login";
		$resultado=$conexion->prepare($sql);	
		$resultado->execute(array(":login"=>$login1)); //ejecuta la sentencia buscandolos correos que sean = al que introdujo el usuario
		while($registro=$resultado->fetch(PDO::FETCH_ASSOC)) 
		{ //registro se convertio en un objeto y un array para hacer el llamado mas adelante	
			
			if(password_verify($password1, $registro["password"]))  //esta funcion verifica o compara el primer argumento q es las PASS q viene del formulario, y la PASS que esta cifrada en la BD q esta cifrada
			{//si el correo exite y la clave es comparada y es y son iguales
				$contador++;// el contador es para tomar decisiones
			}
			$login=$registro["correo"]; //hago esta conversion para llevarme al usuario una vez se logue y poder llamarlo por su nombre

		 //hago esta conversion para llevarme al usuariouna vez se logue y poder llamarlo por su nombre
			
		}
			
			
		if($contador==1) //si es  entonces correo y paas coincidieron, ahora falta evaluar si realizo el pago o esta en espera.
		{
			SESSION_START();
			$_SESSION["login"]=$login1;
			header("location:registro_user.php");
				//ver_verificado($ID, $login);
		}
			if($contador==0){

				header("location:index.php");

				//echo"el correo y la password no estan registrados";
				/* $error="Datos no registrados, vuelva a intertarlo";
				header("location:portada.php?contador=$error");
			//echo "correo o password mala ,  ver contador2 es : " . $contador; */
			}
	}
	
	
	


?>